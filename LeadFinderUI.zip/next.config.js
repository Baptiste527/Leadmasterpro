module.exports = {
  reactStrictMode: true,
  output: "standalone"
};
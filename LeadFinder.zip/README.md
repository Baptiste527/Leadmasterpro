# Lead Finder UI

## 🚀 Installation et Lancement

1. **Cloner le projet :**
   ```
   git clone https://github.com/ton-repo/lead-finder-ui.git
   cd lead-finder-ui
   ```

2. **Installer les dépendances :**
   ```
   npm install
   ```

3. **Lancer le projet en local :**
   ```
   npm run dev
   ```

4. **Déployer sur Vercel :**
   ```
   npm run deploy
   ```
